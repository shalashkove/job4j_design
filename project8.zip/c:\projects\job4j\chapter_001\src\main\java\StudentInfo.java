
public class StudentInfo {

    public static void main(String[] args) {
        System.out.println("Evgeny Shalashkov");
        System.out.println("24/05/1980");
    }
}
