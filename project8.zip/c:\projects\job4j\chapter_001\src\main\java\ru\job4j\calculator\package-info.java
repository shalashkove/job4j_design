/**
 * Package for calculate task.
 *
 * @author Evgeny Shalashkov (shalashkove@gmail.com)
 * @version $Id$
 * @since 29.08.2019
 */
package ru.job4j.calculator;