[![Build Status](https://travis-ci.org/shalashkove/job4j.svg?branch=master)](https://travis-ci.org/shalashkove/job4j)
[![codecov](https://codecov.io/gh/shalashkove/job4j/branch/master/graph/badge.svg)](https://codecov.io/gh/shalashkove/job4j)

# job4j
for java study
... adding data
я начал курс в августе 2019
планирую закончить в мае 2020

Объединение зафиксированных измененИй

Создание ветки из IDEA

В курсе производилась работа с ветками git.