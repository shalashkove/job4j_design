package ru.job4j.oop;

public class Ball {
    public void tryEat(Ball ball) {
        System.out.println("Не могу съесть сам себя!");
        System.out.println("... на самом деле в этом месте колобок убежал от бабки с дедкой.");
    }
}
