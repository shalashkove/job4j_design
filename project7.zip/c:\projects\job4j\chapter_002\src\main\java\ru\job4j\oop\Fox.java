package ru.job4j.oop;

public class Fox {
    public void tryEat(Ball ball) {
        System.out.println("Хотел колобок и лису обмануть как остальных.");
        System.out.println("Но получилось наоборот - съела его лиса!");
        System.out.println("Тут и сказочке конец.");
    }
}
